# LetsRoll2RS > 2024-03-12 9:13pm
https://universe.roboflow.com/rollingshutterpedestriandetection/letsroll2rs

Provided by a Roboflow user
License: CC BY 4.0

