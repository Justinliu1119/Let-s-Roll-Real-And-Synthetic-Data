# letsroll2_real_gs > 2024-03-16 5:24pm
https://universe.roboflow.com/letsroll2-ij8uy/letsroll2_real_gs

Provided by a Roboflow user
License: CC BY 4.0

